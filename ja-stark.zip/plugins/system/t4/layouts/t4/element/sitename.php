<?php
$doc = $displayData->doc;
$sitename = $doc->params->get('sitetitle', 'none');
?>

<h1 class="t4-site-name"><?php echo $sitename ?></h1>